import StringApp.*;
import org.omg.CORBA.*;
import org.omg.PortableServer.*;
import java.io.*;

public class StringServer {
    public static void main(String args[]) {
        try {
            ORB orb = ORB.init(args, null);
            POA rootpoa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
            rootpoa.the_POAManager().activate();

            StringImpl stringImpl = new StringImpl();
            stringImpl.setORB(orb);

            org.omg.CORBA.Object ref = rootpoa.servant_to_reference(stringImpl);
            StringOperations href = StringOperationsHelper.narrow(ref);

            FileWriter file = new FileWriter("String.ref");
            file.write(orb.object_to_string(href));
            file.close();

            System.out.println("StringOperations Server is ready...");
            orb.run();
        } catch (Exception e) {
            System.err.println("Server Exception: " + e);
        }
    }
}
