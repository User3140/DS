import StringApp.*;
import org.omg.CORBA.*;
import java.nio.file.*;

public class StringClient {
    public static void main(String args[]) {
        try {
            ORB orb = ORB.init(args, null);

            String ior = new String(Files.readAllBytes(Paths.get("String.ref")));
            org.omg.CORBA.Object objRef = orb.string_to_object(ior);
            StringOperations stringRef = StringOperationsHelper.narrow(objRef);

            System.out.println("Original: HelloWorld");
            System.out.println("Uppercase: " + stringRef.toUpper("HelloWorld"));
            System.out.println("Lowercase: " + stringRef.toLower("HelloWorld"));
            System.out.println("Reversed: " + stringRef.reverse("HelloWorld"));
            System.out.println("Is 'madam' a palindrome? " + stringRef.isPalindrome("madam"));

        } catch (Exception e) {
            System.err.println("Client Exception: " + e);
        }
    }
}
