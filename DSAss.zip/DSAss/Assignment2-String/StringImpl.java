import StringApp.*;
import org.omg.CORBA.*;

public class StringImpl extends StringOperationsPOA {
    private ORB orb;

    public void setORB(ORB orb_val) {
        orb = orb_val;
    }

    public String toUpper(String input) {
        return input.toUpperCase();
    }

    public String toLower(String input) {
        return input.toLowerCase();
    }

    public String reverse(String input) {
        return new StringBuilder(input).reverse().toString();
    }

    public boolean isPalindrome(String input) {
        String reversed = new StringBuilder(input).reverse().toString();
        return input.equalsIgnoreCase(reversed);
    }
}
