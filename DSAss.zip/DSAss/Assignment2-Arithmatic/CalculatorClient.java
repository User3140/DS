import CalculatorApp.*;
import org.omg.CORBA.*;

public class CalculatorClient {
    public static void main(String args[]) {
        try {
            ORB orb = ORB.init(args, null);

            String ior = new String(java.nio.file.Files.readAllBytes(java.nio.file.Paths.get("Calculator.ref")));
            org.omg.CORBA.Object objRef = orb.string_to_object(ior);
            Calculator calcRef = CalculatorHelper.narrow(objRef);

            System.out.println("Calling remote methods:");
            System.out.println("10 + 5 = " + calcRef.add(10, 5));
            System.out.println("10 - 5 = " + calcRef.subtract(10, 5));
            System.out.println("10 * 5 = " + calcRef.multiply(10, 5));
            System.out.println("10 / 5 = " + calcRef.divide(10, 5));

        } catch (Exception e) {
            System.err.println("Client Error: " + e);
        }
    }
}
