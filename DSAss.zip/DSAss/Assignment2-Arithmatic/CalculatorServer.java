import CalculatorApp.*;
import org.omg.CORBA.*;
import org.omg.PortableServer.*;
import org.omg.PortableServer.POA;
import java.util.Properties;

public class CalculatorServer {
    public static void main(String args[]) {
        try {
            ORB orb = ORB.init(args, null);
            POA rootpoa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
            rootpoa.the_POAManager().activate();

            CalculatorImpl calcImpl = new CalculatorImpl();
            calcImpl.setORB(orb);

            org.omg.CORBA.Object ref = rootpoa.servant_to_reference(calcImpl);
            Calculator href = CalculatorHelper.narrow(ref);

            java.io.FileWriter file = new java.io.FileWriter("Calculator.ref");
            file.write(orb.object_to_string(href));
            file.close();

            System.out.println("Calculator Server is ready and waiting...");
            orb.run();
        } catch (Exception e) {
            System.err.println("Server Error: " + e);
        }
    }
}
