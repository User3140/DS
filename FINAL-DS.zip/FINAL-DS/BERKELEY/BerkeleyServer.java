import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class BerkeleyServer {

    static class ClientInfo {
        Socket socket;
        long timeDiff;

        ClientInfo(Socket socket) {
            this.socket = socket;
        }
    }

    static Map<String, ClientInfo> clients = new ConcurrentHashMap<>();

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(9090);
        System.out.println("Clock Server started on port 8080...");

        // Accept clients
        new Thread(() -> {
            while (true) {
                try {
                    Socket socket = serverSocket.accept();
                    String clientId = socket.getRemoteSocketAddress().toString();
                    clients.put(clientId, new ClientInfo(socket));
                    System.out.println(clientId + " connected.");
                    new Thread(() -> handleClient(socket, clientId)).start();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();

        // Synchronization cycle every 5 seconds
        new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(5000);
                    synchronizeClocks();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    static void handleClient(Socket socket, String clientId) {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            while (true) {
                String clientTimeStr = in.readLine();
                long clientTime = Long.parseLong(clientTimeStr);
                long serverTime = System.currentTimeMillis();
                long diff = serverTime - clientTime;

                clients.get(clientId).timeDiff = diff;

                System.out.println("Client " + clientId + " time diff = " + diff + " ms");
                Thread.sleep(5000);
            }
        } catch (Exception e) {
            System.out.println("Disconnected: " + clientId);
            clients.remove(clientId);
        }
    }

    static void synchronizeClocks() {
        if (clients.isEmpty()) {
            System.out.println("No clients connected.");
            return;
        }

        long totalDiff = 0;
        for (ClientInfo client : clients.values()) {
            totalDiff += client.timeDiff;
        }

        long avgDiff = totalDiff / (clients.size() + 1); // including master
        long syncTime = System.currentTimeMillis() + avgDiff;

        System.out.println("Synchronizing clients to: " + new Date(syncTime));

        for (ClientInfo client : clients.values()) {
            try {
                PrintWriter out = new PrintWriter(client.socket.getOutputStream(), true);
                out.println(syncTime);
            } catch (IOException e) {
                System.out.println("Failed to send sync time to a client.");
            }
        }

        System.out.println();
    }
}
