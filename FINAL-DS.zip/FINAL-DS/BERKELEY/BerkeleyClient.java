import java.io.*;
import java.net.*;
import java.util.Date;

public class BerkeleyClient {

    public static void main(String[] args) throws Exception {
        Socket socket = new Socket("127.0.0.1", 9090);
        System.out.println("Connected to Clock Server.");

        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

        // Thread to send current time
        new Thread(() -> {
            while (true) {
                try {
                    long currentTime = System.currentTimeMillis();
                    out.println(currentTime);
                    System.out.println("Sent local time: " + new Date(currentTime));
                    Thread.sleep(5000);
                } catch (Exception e) {
                    System.out.println("Error sending time.");
                }
            }
        }).start();

        // Thread to receive synchronized time
        new Thread(() -> {
            while (true) {
                try {
                    String syncTimeStr = in.readLine();
                    if (syncTimeStr != null) {
                        long syncTime = Long.parseLong(syncTimeStr);
                        System.out.println("Received synchronized time: " + new Date(syncTime));
                    }
                } catch (Exception e) {
                    System.out.println("Error receiving sync time.");
                }
            }
        }).start();
    }
}
