import java.util.*;

public class ElectionAlgorithms {
    static class Bully {
        int coordinator;
        int max_processes;
        boolean processes[];

        public Bully(int max) {
            max_processes = max;
            processes = new boolean[max_processes];
            coordinator = max;
            System.out.println("Creating processes..");
            for (int i = 0; i < max; i++) {
                processes[i] = true;
                System.out.println("P" + (i + 1) + " created");
            }
            System.out.println("Process P" + coordinator + " is the coordinator");
        }

        void displayProcesses() {
            for (int i = 0; i < max_processes; i++) {
                System.out.println("P" + (i + 1) + " is " + (processes[i] ? "up" : "down"));
            }
            System.out.println("Process P" + coordinator + " is the coordinator");
        }

        void upProcess(int process_id) {
            if (!processes[process_id - 1]) {
                processes[process_id - 1] = true;
                System.out.println("Process " + process_id + " is now up.");
            } else {
                System.out.println("Process " + process_id + " is already up.");
            }
        }

        void downProcess(int process_id) {
            if (!processes[process_id - 1]) {
                System.out.println("Process " + process_id + " is already down.");
            } else {
                processes[process_id - 1] = false;
                System.out.println("Process " + process_id + " is down.");
            }
        }

        void runElection(int process_id) {
            coordinator = process_id;
            boolean keepGoing = true;

            for (int i = process_id; i < max_processes && keepGoing; i++) {
                System.out.println("Election message sent from process " + process_id + " to process " + (i + 1));
                if (processes[i]) {
                    keepGoing = false;
                    runElection(i + 1);
                }
            }
        }
    }

    static class Ring {
        int max_processes;
        int coordinator;
        boolean processes[];
        ArrayList<Integer> pid;

        public Ring(int max) {
            coordinator = max;
            max_processes = max;
            pid = new ArrayList<>();
            processes = new boolean[max];

            for (int i = 0; i < max; i++) {
                processes[i] = true;
                System.out.println("P" + (i + 1) + " created.");
            }
            System.out.println("P" + coordinator + " is the coordinator");
        }

        void displayProcesses() {
            for (int i = 0; i < max_processes; i++) {
                System.out.println("P" + (i + 1) + " is " + (processes[i] ? "up." : "down."));
            }
            System.out.println("P" + coordinator + " is the coordinator");
        }

        void upProcess(int process_id) {
            if (!processes[process_id - 1]) {
                processes[process_id - 1] = true;
                System.out.println("Process P" + process_id + " is up.");
            } else {
                System.out.println("Process P" + process_id + " is already up.");
            }
        }

        void downProcess(int process_id) {
            if (!processes[process_id - 1]) {
                System.out.println("Process P" + process_id + " is already down.");
            } else {
                processes[process_id - 1] = false;
                System.out.println("Process P" + process_id + " is down.");
            }
        }

        void displayArrayList(ArrayList<Integer> pid) {
            System.out.print("[ ");
            for (Integer x : pid) {
                System.out.print(x + " ");
            }
            System.out.println("]");
        }

        void initElection(int process_id) {
            if (processes[process_id - 1]) {
                pid.add(process_id);
                int temp = process_id;

                do {
                    temp = (temp) % max_processes;
                    if (processes[temp]) {
                        pid.add(temp + 1);
                        System.out.print("Process P" + (temp + 1) + " sending the following list:- ");
                        displayArrayList(pid);
                    }
                    temp = (temp + 1) % max_processes;
                } while (temp != (process_id - 1));

                coordinator = Collections.max(pid);
                System.out.println("Process P" + process_id + " has declared P" + coordinator + " as the coordinator");
                pid.clear();
            }
        }
    }

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        Bully bully = null;
        Ring ring = null;
        int choice, algo_choice, max_processes, process_id;

        System.out.println("Select Election Algorithm:");
        System.out.println("1. Bully Algorithm");
        System.out.println("2. Ring Algorithm");
        System.out.print("Enter your choice: ");
        algo_choice = sc.nextInt();

        while (true) {
            System.out.println("\nMenu");
            System.out.println("1. Create processes");
            System.out.println("2. Display processes");
            System.out.println("3. Up a process");
            System.out.println("4. Down a process");
            System.out.println("5. Run election algorithm");
            System.out.println("6. Exit Program");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter number of processes: ");
                    max_processes = sc.nextInt();
                    if (algo_choice == 1)
                        bully = new Bully(max_processes);
                    else
                        ring = new Ring(max_processes);
                    break;
                case 2:
                    if (algo_choice == 1)
                        bully.displayProcesses();
                    else
                        ring.displayProcesses();
                    break;
                case 3:
                    System.out.print("Enter process number to up: ");
                    process_id = sc.nextInt();
                    if (algo_choice == 1)
                        bully.upProcess(process_id);
                    else
                        ring.upProcess(process_id);
                    break;
                case 4:
                    System.out.print("Enter process number to down: ");
                    process_id = sc.nextInt();
                    if (algo_choice == 1)
                        bully.downProcess(process_id);
                    else
                        ring.downProcess(process_id);
                    break;
                case 5:
                    System.out.print("Enter process number to initiate election: ");
                    process_id = sc.nextInt();
                    if (algo_choice == 1) {
                        bully.runElection(process_id);
                        bully.displayProcesses();
                    } else {
                        ring.initElection(process_id);
                    }
                    break;
                case 6:
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}