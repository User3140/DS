import java.util.*;
public class TokenRing {

  public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    System.out.print("Enter number of nodes you want in the ring: ");
    int n=sc.nextInt();

    System.out.print("Ring formed is as below: ");
    for(int i=0;i<n;i++)
    {
      System.out.print(i +" ");
    }
    System.out.print("0");

    int choice=0;

    do{
      System.out.println( );
      System.out.print("Enter sender: ");
      int sender=sc.nextInt();

      System.out.print("Enter reciever: ");
      int reciever=sc.nextInt();

      System.out.print("Enter data: ");
      int data=sc.nextInt();

      int token=0;
      System.out.print("Token passing: ");

      for(int i=token;i<sender;i++)
      {
        System.out.print(" "+i+"->");
      }
      System.out.println(" "+sender);
      System.out.println("sender: "+sender+" sending data: "+ data);
      
      for(int i=sender;i!=reciever;i=(i+1)%n){
        System.out.println("Data: "+data+" forwarded by: "+i);
      }

      System.out.println("Reciever  "+reciever+" Received the "+data);

      token=sender;

      System.out.println("Do you want to send data again if yes enter 1, If no Enter 0");
      choice=sc.nextInt();
    }while(choice==1);
  }
}